#ifndef __ADC_H
#define	__ADC_H

#include "stm32f10x.h"



void Adc_Init(void);
float Adc_Get_Measure_Volotage(void);
float Adc_Get_Battery_Volotage(void);





#endif