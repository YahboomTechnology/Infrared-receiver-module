#include "stm32f10x.h"
#include "Delay.h"
#include "usart.h"
#include "GPIO.h"
#include "adc.h"
#include "remote.h"

	u8 key;

uint16_t abv;
 int main()
	 {

			USART_Config();
  		Adc_Init();
			Remote_Init();
		 
		while(1)
	{
		
		key=Remote_Scan();	
		if(key)
		{	 
			printf("key is %x\r\n",key);
		}
	}
	}

